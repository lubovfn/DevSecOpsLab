# NetworkPolicy Lab (Kind/Kubernetes)

> ВАЖНО: Для применения NetworkPolicy требуется CNI с поддержкой политик (Calico, Cilium и т.п.).
> В kind по умолчанию политика может не применяться. Установите, например, Calico согласно официальной документации.

## Шаги
```bash
# Namespace
kubectl apply -f manifests/networkpolicy/ns-lab.yaml

# Приложения
kubectl apply -f manifests/apps/web.yaml
kubectl apply -f manifests/apps/db.yaml

# Политики
kubectl apply -f manifests/networkpolicy/np-default-deny-all.yaml
kubectl apply -f manifests/networkpolicy/np-allow-dns-egress.yaml
kubectl apply -f manifests/networkpolicy/np-allow-web-to-db.yaml
kubectl apply -f manifests/networkpolicy/np-allow-same-app.yaml
```

## Тесты
```bash
# Запустим test pod в том же ns
kubectl -n lab run test --rm -it --image=curlimages/curl -- /bin/sh

# 1) По умолчанию всё заблокировано: нет доступа к web и db
curl -sS web.lab.svc.cluster.local:80 || echo "blocked"
curl -sS db.lab.svc.cluster.local:5432 || echo "blocked"

# 2) С pod с меткой app=web доступ к db:5432 должен быть разрешён
kubectl -n lab run web-test --image=curlimages/curl -l app=web -it --rm --   sh -lc 'nc -vz db 5432 || true'

# 3) DNS работает благодаря allow-dns-egress
nslookup kubernetes.default.svc.cluster.local || true
```
